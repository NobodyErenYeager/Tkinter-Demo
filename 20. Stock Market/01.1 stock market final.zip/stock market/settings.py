TIME_OPTIONS = ['Max', '1 Year', '6 Months', 'Month', 'Week']

# colors 
BG_COLOR = '#19233c'
INPUT_BG_COLOR = '#121a2c'
TICK_COLOR = '#EEEEEE'
HIGHLIGHT_COLOR = '#21eaad'
TEXT_COLOR = '#FFFFFF'
TITLE_HEX_COLOR = 0x003c2319