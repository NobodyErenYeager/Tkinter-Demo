import customtkinter as ctk 
from settings import *

class Game(ctk.CTk):
	def __init__(self):

		# setup
		super().__init__()
		self.title('Snake')
		self.geometry(f'{WINDOW_SIZE[0]}x{WINDOW_SIZE[1]}')

		# layout 
		print(list(range(FIELDS[0])))
		# self.columnconfigure()
		# exercise: get the FIELDS and turn it into columns and rows

		# run
		self.mainloop()

Game()